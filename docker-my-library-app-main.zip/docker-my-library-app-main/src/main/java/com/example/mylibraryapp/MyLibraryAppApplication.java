package com.example.mylibraryapp;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class MyLibraryAppApplication {

	public static void main(String[] args) {
		SpringApplication.run(MyLibraryAppApplication.class, args);
	}

}
